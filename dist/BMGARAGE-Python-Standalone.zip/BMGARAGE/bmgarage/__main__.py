"""Native Python command line; no Java or E-Sys installation is required."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from .engine import Engine, EngineError
from .settings import load_preferences


def main() -> int:
    parser = argparse.ArgumentParser(description="BMGARAGE standalone Python application")
    parser.add_argument("--psdzdata", type=Path, help="Manually selected psdzdata directory or its parent")
    parser.add_argument("--state-dir", type=Path, help="Application-owned settings directory")
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("info", help="Report the native application engine")
    sub.add_parser("data", help="Inspect the manually selected dataset location")
    inspect = sub.add_parser("inspect", help="Inspect a saved document using the Python engine")
    inspect.add_argument("kind", choices=["fa", "fp", "svt", "tal"])
    inspect.add_argument("file", type=Path)
    inspect.add_argument("--entry", type=int, help="FAList entry number, starting at 1")
    inspect.add_argument("--fa", type=Path, help="Matching FA/FAList for saved FP VPC comparison")
    resources = sub.add_parser("fp-resources", help="Locate actual FA2FP files in the selected dataset")
    resources.add_argument("series", help="Exact development-series value from the FA")
    step = sub.add_parser("istep", help="Parse or compare I-Step identifiers")
    step.add_argument("value")
    step.add_argument("other", nargs="?")
    vin = sub.add_parser("read-vin", help="Read only UDS F190 from an explicit ENET endpoint; no discovery")
    vin.add_argument("--protocol", choices=["hsfz", "doip"], required=True)
    vin.add_argument("--host", required=True, help="Numeric IP address of the ENET endpoint")
    vin.add_argument("--target", type=lambda value: int(value, 0), required=True, help="Known physical ECU address, decimal or 0x hex")
    vin.add_argument("--tester", type=lambda value: int(value, 0), help="Tester address, decimal or 0x hex")
    vin.add_argument("--port", type=int, help="Explicit TCP port; defaults: HSFZ 6801, DoIP 13400")
    vin.add_argument("--doip-version", type=int, choices=[2, 3], help="Explicit DoIP version; default 3")
    vin.add_argument("--connect-timeout", type=float, default=3)
    vin.add_argument("--response-timeout", type=float, default=5)
    vin.add_argument("--tls", action="store_true", help="Use verifying DoIP TLS; no plaintext fallback")
    vin.add_argument("--tls-ca", type=Path, help="Trusted CA PEM for DoIP TLS; otherwise use system trust")
    vin.add_argument("--tls-name", help="Certificate hostname; otherwise verify the numeric endpoint IP")
    sub.add_parser("gui", help="Launch BMGARAGE")
    options = parser.parse_args()
    try:
        data_home = options.psdzdata or load_preferences(options.state_dir).get("data_home")
        if options.command in (None, "gui"):
            from .gui import run_gui
            run_gui(data_home=data_home, state_dir=options.state_dir)
            return 0
        with Engine(data_home=data_home, state_dir=options.state_dir) as engine:
            if options.command == "info":
                result = engine.call("system.info")
            elif options.command == "data":
                result = engine.call("data.status")
            elif options.command == "fp-resources":
                result = engine.call("fp.resources", {"series": options.series})
            elif options.command == "read-vin":
                args = {"protocol": options.protocol, "host": options.host, "targetAddress": options.target,
                        "connectTimeout": options.connect_timeout, "responseTimeout": options.response_timeout,
                        "tls": options.tls}
                for key, value in (("port", options.port), ("testerAddress", options.tester),
                                   ("protocolVersion", options.doip_version), ("tlsCa", options.tls_ca),
                                   ("tlsName", options.tls_name)):
                    if value is not None:
                        args[key] = str(value) if isinstance(value, Path) else value
                result = engine.call("diagnostics.vin", args)
            elif options.command == "istep":
                if options.other is None:
                    result = engine.call("istep.parse", {"value": options.value})
                else:
                    result = engine.call("istep.compare", {"left": options.value, "right": options.other})
            else:
                with options.file.open("rb") as source:
                    document = source.read(8 * 1024 * 1024 + 1)
                if len(document) > 8 * 1024 * 1024:
                    raise ValueError("Document exceeds 8 MiB.")
                args = {"xml": document.decode("utf-8-sig")}
                if options.fa is not None:
                    if options.kind != "fp":
                        raise ValueError("The --fa argument applies only to saved FP checksum comparison.")
                    with options.fa.open("rb") as source:
                        matching = source.read(8 * 1024 * 1024 + 1)
                    if len(matching) > 8 * 1024 * 1024:
                        raise ValueError("Matching FA document exceeds 8 MiB.")
                    args["faXml"] = matching.decode("utf-8-sig")
                if options.entry is not None:
                    if options.entry < 1:
                        raise ValueError("FAList entry numbers start at 1.")
                    args["entryIndex"] = options.entry - 1
                result = engine.call(options.kind + ".inspect", args)
            print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (EngineError, OSError, ValueError, UnicodeError) as exc:
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
